//============================================================//
// File:		Render2DCore.h
// 
// Date:		10-19-2000
//============================================================//
#ifndef RENDER2DCORE_H
#define RENDER2DCORE_H

#include <windows.h>
#include <ddraw.h>

#include "beTypes.h"
#include "beScreen.h"
#include "beSurface.h"

#endif